#!/bin/bash

echo "GASS BORR"
sleep 5
python main.py +15303250554 doge &
python main.py +16202818534 doge &
python main.py +13044548890 doge &
python main.py +12173398054 doge &
python main.py +13195261372 doge &
python main.py +18123089110 doge &
python main.py +13343362537 doge &
python main.py +16184080816 doge &
python main.py +15412345547 doge &
python main.py +16812491205 doge &
python main.py +14692107102 doge &
python main.py +17246191084 doge &
sleep 360
sh asu.sh
