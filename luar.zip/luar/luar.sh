#!/bin/bash

echo "GASS BORR"
sleep 5
python telemaxv7.3.3.py +15303250554 doge &
python telemaxv7.3.3.py +16202818534 doge &
python telemaxv7.3.3.py +13044548890 doge 

sleep 300
python telemaxv7.3.3.py +12173398054 doge &
python telemaxv7.3.3.py +13195261372 doge &
python telemaxv7.3.3.py +18123089110 doge 

sleep 300
python telemaxv7.3.3.py +13343362537 doge &
python telemaxv7.3.3.py +16184080816 doge &
python telemaxv7.3.3.py +15412345547 doge 

sleep 300
python telemaxv7.3.3.py +16812491205 doge &
python telemaxv7.3.3.py +14692107102 doge &
python telemaxv7.3.3.py +17246191084 doge 

sleep 3600
sh luar.sh