php sesi2bash.php
sh multiakun.sh